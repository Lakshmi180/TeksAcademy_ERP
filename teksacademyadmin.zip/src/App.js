import logo from "./logo.svg";
import "./App.css";
import Sidebar from "./components/common/sidebar/Sidebar";
// import Sidebar from './components/common/sidebar/Sidebar';


function App() {
  return (
    <div className="App">
      <Sidebar/>
    </div>
  );
}

export default App;
