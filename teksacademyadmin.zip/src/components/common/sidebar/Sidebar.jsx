import React from "react";
import { useTheme } from "../../../context/ThemeContext";

const Sidebar = () => {
  const { theme, setDarkMode } = useTheme();
  console.log(theme);
  return (
    <div className={theme === "light" ? "wrap" : "wrap darkMode"}>
      <nav className="nav-side-menu">
        <div className="logo_section">Site Logo </div>
        <i
          className="fa fa-bars fa-2x toggle-btn"
          data-toggle="collapse"
          data-target="#menu-content"
        ></i>
        <div className="menu-list">
          {/* dashboard */}
          <ul id="menu-content" className="menu-content collapse out">
            <li>
              <a href="#" className="main_menu">
                <i className="fa fa-fw fa-dashboard fa-lg"></i>Dashboard
              </a>
            </li>
            {/* User Management */}
            <li
              data-toggle="collapse"
              data-target="#products"
              className="collapsed"
              data-parent="#menu-content"
            >
              <a href="#" className="main_menu">
                <i className="fa fa-fw fa-gift fa-lg"></i>User Management
                <i className="fa fa-chevron-down"></i>
              </a>
            </li>
            <ul className="sub-menu collapse" id="products">
              <li className="active sub-item">
                <a href="#">
                  <i className="fa fa-circle-o" aria-hidden="true"></i>Create
                  User
                </a>
              </li>
              <li>
                <a href="#" className="sub-item">
                  <i className="fa fa-circle-o" aria-hidden="true"></i>User
                  Details
                </a>
              </li>
            </ul>
            {/* Student Management */}
            <li
              data-toggle="collapse"
              data-target="#studentmanagement"
              className="collapsed"
              data-parent="#menu-content"
            >
              <a href="#" className="main_menu">
                <i className="fa fa-fw fa-table fa-lg"></i>Student Management
                <i className="fa fa-chevron-down"></i>
              </a>
            </li>
            <ul className="sub-menu collapse" id="studentmanagement">
              <li className="sub-item">
                <a href="#">
                  <i className="fa fa-circle-o" aria-hidden="true"></i>
                  Registration Form
                </a>
              </li>
              <li className="sub-item">
                <a href="#">
                  <i className="fa fa-circle-o" aria-hidden="true"></i>Enrolled
                  Students
                </a>
              </li>
              <li className="sub-item">
                <a href="#">
                  <i className="fa fa-circle-o" aria-hidden="true"></i>Fee
                  Details
                </a>
              </li>
              <li className="sub-item">
                <a href="#">
                  <i className="fa fa-circle-o" aria-hidden="true"></i>
                  Certificate
                </a>
              </li>
              <li className="sub-item">
                <a href="#">
                  <i className="fa fa-circle-o" aria-hidden="true"></i>Requested
                  Certificate
                </a>
              </li>
              {/* Refund */}
              <li
                data-toggle="collapse"
                data-target="#refund"
                className="collapsed"
                data-parent="#menu-content"
              >
                <a href="#" className="main_menu">
                  <i className="fa fa-fw fa-users fa-lg"></i>Refund{" "}
                  <i className="fa fa-chevron-down"></i>
                </a>
              </li>
              <ul className="sub-menu collapse" id="refund">
                <li className="sub-item">
                  <a href="#">
                    <i className="fa fa-circle-o" aria-hidden="true"></i>Refund
                    Form
                  </a>
                </li>
                <li className="sub-item">
                  <a href="#">
                    <i className="fa fa-circle-o" aria-hidden="true"></i>Refund
                    Data
                  </a>
                </li>
              </ul>
            </ul>
            {/* Inventory  */}
            <li
              data-toggle="collapse"
              data-target="#inventory"
              className="collapsed"
              data-parent="#menu-content"
            >
              <a href="#" className="main_menu">
                <i className="fa fa-fw fa-users fa-lg"></i>Inventory{" "}
                <i className="fa fa-chevron-down"></i>
              </a>
            </li>
            <ul className="sub-menu collapse" id="inventory">
              <li className="sub-item">
                <a href="#">
                  <i className="fa fa-circle-o" aria-hidden="true"></i>Add
                  Assets
                </a>
              </li>
              <li className="sub-item">
                <a href="#">
                  <i className="fa fa-circle-o" aria-hidden="true"></i>Assign
                  Assets
                </a>
              </li>
            </ul>

            {/* Leads */}
            <li
              data-toggle="collapse"
              data-target="#leads"
              className="collapsed"
              data-parent="#menu-content"
            >
              <a href="#" className="main_menu">
                <i className="fa fa-fw fa-users fa-lg"></i>Leads{" "}
                <i className="fa fa-chevron-down"></i>
              </a>
            </li>
            <ul className="sub-menu collapse" id="leads">
              <li
                data-toggle="collapse"
                data-target="#websiteleads"
                className="collapsed"
                data-parent="#menu-content"
              >
                <a href="#">
                  <i className="fa fa-fw fa-users fa-lg"></i>Website Leads{" "}
                  <i className="fa fa-chevron-down"></i>
                </a>
              </li>
              <ul className="sub-menu collapse" id="websiteleads">
                <li className="sub-item">
                  <a href="#">
                    <i className="fa fa-circle-o" aria-hidden="true"></i>Webinar
                  </a>
                </li>
                <li className="sub-item">
                  <a href="#">
                    <i className="fa fa-circle-o" aria-hidden="true"></i>
                    WhatsApp
                  </a>
                </li>
                <li className="sub-item">
                  <a href="#">
                    <i className="fa fa-circle-o" aria-hidden="true"></i>
                    Download Syllabus
                  </a>
                </li>
                <li className="sub-item">
                  <a href="#">
                    <i className="fa fa-circle-o" aria-hidden="true"></i>View
                    Course
                  </a>
                </li>
                <li className="sub-item">
                  <a href="#">
                    <i className="fa fa-circle-o" aria-hidden="true"></i>Contact
                    Us
                  </a>
                </li>
                <li className="sub-item">
                  <a href="#">
                    <i className="fa fa-circle-o" aria-hidden="true"></i>Hlp
                    Enquire Leads
                  </a>
                </li>
                <li className="sub-item">
                  <a href="#">
                    <i className="fa fa-circle-o" aria-hidden="true"></i>Slp
                    Enquire Leads
                  </a>
                </li>
              </ul>
            </ul>
            {/* Reports */}
            <li
              data-toggle="collapse"
              data-target="#reportsdata"
              className="collapsed"
              data-parent="#menu-content"
            >
              <a href="#" className="main_menu">
                <i className="fa fa-fw fa-users fa-lg"></i>Reports{" "}
                <i className="fa fa-chevron-down"></i>
              </a>
            </li>
            <ul className="sub-menu collapse" id="reportsdata">
              <li className="sub-item">
                <a href="#">
                  <i className="fa fa-circle-o" aria-hidden="true"></i>Reports
                  Data
                </a>
              </li>
            </ul>
            {/* Settings */}
            <li>
              <a href="#" className="main_menu">
                <i className="fa fa-fw fa-dashboard fa-lg"></i>Settings
              </a>
            </li>
          </ul>
        </div>
      </nav>
      <div className="content_here">
        <button className="btn btn-primary" onClick={setDarkMode}>
          Toggle
        </button>
      </div>
    </div>
  );
};
export default Sidebar;
